# Work Hours — Telegram Mini App (CloudStorage edition)

This version is designed for a personal Telegram Mini App and stores the app data in Telegram Mini App CloudStorage instead of an external database.

Features:
- Daily shift entry
- Workplace
- Start/end
- Pause
- Automatic net-hours calculation
- Edit every shift
- Delete every shift
- Daily/weekly/monthly/yearly summaries
- Salary calculation:
  - company salary / 13.90 = company-paid hours
  - monthly net hours - company-paid hours = remaining hours
  - remaining hours * 13 = cash payment
- Monthly printable PDF-style report
- Settings
- Data can be available on Telegram clients where the same Mini App/user CloudStorage is available

Telegram's official Mini Apps documentation says CloudStorage provides up to 1024 items per user per bot, with values up to 4096 characters. DeviceStorage is local to the device and is not used for the main data here.

Important: Telegram still requires the Mini App HTML/JavaScript to be served from a web URL. This project does NOT require an external database or backend server for the data.

## Local preview

Open `static/index.html` in a browser for UI preview. Telegram storage APIs are only available when the app is actually launched inside Telegram.

## Telegram setup

1. Create a bot with @BotFather.
2. Create/configure its Main Mini App and provide a public HTTPS URL containing `static/index.html`.
3. Open the bot's Mini App in Telegram.

For a zero-cost hosting route, a static host such as GitHub Pages/Cloudflare Pages can serve the HTML files. The project itself does not require a paid database.
